Course Name: CS373
Unique: 91055

First Name: Calvin
Last Name: Szeto
EID: CS37888
E-mail: szeto.calvin@gmail.com
Estimated number of hours: 10
Actual    number of hours: 20

Turnin CS Username:     calvins
GitHub ID:              calvinszeto
GitHub Repository Name: cs373-wc
Google App Engine URL:  calvins-cs373-wc.appspot.com

<repeat for each group member>

Group Member First Name: Kevin
Group Member Last Name: Tang
Group Member EID: KLT592
Group Member E-mail: tangkevin@utexas.edu
Group Member Rating:           Excellent
Group Member Point Adjustment: no change

Group Member First Name: Connor
Group Member Last Name: Bowman
Group Member EID: CWB658
Group Member E-mail: bowmancw@sbcglobal.net
Group Member Rating:           Excellent
Group Member Point Adjustment: no change

Group Member First Name: Kevin
Group Member Last Name: Jacoby
Group Member EID: KJ5378
Group Member E-mail: kevinjacoby@utexas.edu
Group Member Rating:           Excellent
Group Member Point Adjustment: no change

Group Member First Name: Daniel
Group Member Last Name: Finan
Group Member EID: DRF525
Group Member E-mail: dfinan09@gmail.com
Group Member Rating:           Excellent
Group Member Point Adjustment: no change

Comments:

--------------------
Group Member Ratings
--------------------

Excellent: consistently went above and beyond; tutored partner; carried more than her fair share of the load.

Very Good: consistently did what she was supposed to do; very well prepared and cooperative.

Satisfactory: usually did what she was supposed to do; minimally prepared and cooperative.

Marginal: sometimes failed to show up; rarely prepared.

Deficient: often failed to show up; rarely prepared.

Unsatisfactory: consistently failed to show up; unprepared.

Superficial: practically no participation.

No Show: no participation at all.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
